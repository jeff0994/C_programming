/* UNIVERSIDAD DE COSTA RICA 
 * ESCUELA DE FISICA
 * CURSO: FS0733 TOPICOS DE METODOS MATEMATICOS DE LA FISICA
 * TEMA: FISICA COMPUTACIONAL Y PROGRAMACION EN C/C++ 
 * PROFESOR DAVID SOLANO SOLANO
 * PROGRAMA LECTURA DE UNA FORMACION*/
 
 /* lectura.c MUESTRA COMO SE LEE UN ARREGLO DE UN VECTOR.>
    Copyright (C) 2017  David Solano-Solano

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses. */
    
    
 /* History Log:
  * 
  * V. 0.1 : initial 
  * V. 0.2 : improvements in user interaction*/   
  
    
/* Para correr el programa, aplique el comando en la terminal: 
 * 
 * gcc lectura.c -Wall -o lectura
 * -Wall : muestra advertencias (sugerencias) para mejorar el código
 * -o : le da el nombre <nombre_archivo> al ejecutable*/    


#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<string.h>

#define ENE 3
#define EME 20


void leercadena (char vectorid[]);

void mostrarcadena ( char vectorid[] );

void leervector( double vector[], char vectorid[] ) ;
	
void mostrarvector( double vector[], char vectorid[] );


int main(){
	double uvector[ENE];
	char uvectorid[EME];
	printf("\n\nEscriba el simbolo que identifica al vector: ");
	leercadena(uvectorid);
	mostrarcadena(uvectorid);
	printf("\n\n");
	leervector(uvector, uvectorid);
	mostrarvector(uvector, uvectorid);
}


void leercadena (char vectorid[]){
	int i,j;
	/* Bucle corre hasta que se da "nueva linea" o "ENTER"*/
	for(i=0; (vectorid[i]=getchar()) != '\n'; ++i);
	j=i;
	/* Bucle para rellenar los espacios en blanco con valores nulos*/
	for(i=j; i<=EME; ++i){
		vectorid[i]='\0';}
	return;
	}
	
void mostrarcadena ( char vectorid[] ) {
	int i, numcadena;
	numcadena = strlen( vectorid);
/*	printf("\n\n tamano cadena es: %d \n\n", numcadena); */
	for (i=0; i < numcadena; ++i){
		putchar(vectorid[i]);
	}
	return;
}

void leervector( double vector[], char vectorid[] ) {
	int i;
	printf("\nIntroduzca las componentes del vector %s en orden usual uno en cada linea: \n", vectorid);
	for( i = 0; i < ENE - 1; ++i){
		scanf("%lf ", &vector[i]);
	}
	return;
	}
	
void mostrarvector( double vector[], char vectorid[] ){
	printf("\n%s es: %lf %lf %lf", vectorid, vector[0], vector[1],  vector[2]);
	}



	
