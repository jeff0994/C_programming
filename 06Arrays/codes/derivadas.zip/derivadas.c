#include<stdio.h>
#include<math.h>
#include<stdlib.h>

#define hache 0.001

void imprimir (FILE* archiv, double x);

void bucle ( int mini, int maxi, FILE *archiv);

double calcular (double equis);

double derivar1 (double equis);



main() {
	double ex = 0;
	int minimo, maximo;
	minimo = 0;
	maximo = 4;
	FILE *tabla;
	tabla = fopen("tabla.dat", "w");
	bucle(minimo, maximo, tabla); 
	fclose(tabla);
}


void bucle ( int mini, int maxi, FILE *archiv){
	double equis = mini;
	while ( equis <= maxi ){
		imprimir(archiv, equis); 
	    equis = equis + hache;
	}
	return;
}

void imprimir (FILE* archiv, double equis){
	fprintf(archiv, "%lf %lf %lf \n", equis, calcular(equis), derivar1(equis));
	return;
}

double calcular (double equis) {
	double ret;
	ret  = cos(equis);
	return ret;
}


double derivar1 ( double equis ) {
	double ret;
	ret = (calcular(equis+hache)-calcular(equis)) / hache;
	return ret;
	}
